## README.md

This folder *Source_Data* contains the relevant raw data from each figure and table of the manuscript 
**Subcortical-cortical dynamical states of the human brain and their breakdown in stroke** (Favaretto et al., 2022).

Two excel files are provided:
- *manuscript_Figures_data.xlsx*: raw data of the figures presented in  the main file of the manuscript (each figure is related to a single sheet)
- *SI_Tables_Figures_data.xlsx*: raw data of all tables and figures presented in the Supplementary Information (each table/figure is related to a single sheet)
